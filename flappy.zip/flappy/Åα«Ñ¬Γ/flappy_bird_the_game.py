# import menu_flap
import pygame, time, random
import pygame.sysfont
# import Colors
import pygameMenu

#  После снятия комементария "import menu_flap", не забудь раскомментить 151 строку

pygame.init()

size = width, heigth = 800, 600
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
titles_list = ['Looking for trouble?', 'Wanna play?', 'Making game...', 'Rainbow six: siege',
               'Flappy Bird: ESL Pro league edition']
pygame.display.set_caption(titles_list[random.randint(0, len(titles_list) - 1)])
trigger = False

#  ____________________________________________________________________________________________________________________

class Bird:
    def __init__(self):
        self.speed = 0
        self.acceleration = 0
        self.speed_limit = -50
        self.fall_speed_limit = 30
        # gravity = 10
        self.coords = self.width, self.height = width / 4, heigth / 2
        self.count = 0
        self.image_count = 0
        self.image_list = [pygame.image.load('flappy1.png'), pygame.image.load('flappy2.png'),
                           pygame.image.load('flappy3.png')]
        self.frames = 0
        self.jump_sound = pygame.mixer.Sound('sfx_wing1.wav')

#  ____________________________________________________________________________________________________________________

    def jump(self):
        self.speed -= 20
        self.jump_sound.play()
#  _____________________________________________________________________________________________________________________

    def movement(self):
        self.height = self.height + self.speed * 0.5 + self.acceleration * 0.5 ** 2 / 2
        self.speed += 1
        if self.speed > self.fall_speed_limit:
            self.speed = self.fall_speed_limit
        if self.speed < self.speed_limit:
            self.speed = self.speed_limit

    def get_coordinates(self):
        self.coords = int(self.width), int(self.height)
        return self.coords

    def bird_spawn(self):
        bird_image = pygame.image.load('flappy1.png')
        self.bird_rectangle1 = bird_image.get_rect(topleft=(self.get_coordinates()))
        screen.blit(bird_image, self.bird_rectangle1)

    def draw(self):
        if self.frames <= 5:
            screen.blit(self.image_list[0], self.bird_rectangle1)

        elif self.frames <= 10:
            screen.blit(self.image_list[1], self.bird_rectangle1)

        elif self.frames <= 15:
            screen.blit(self.image_list[2], self.bird_rectangle1)
        else:
            self.frames = 0
        self.frames += 1


#  ____________________________________________________________________________________________________________________

class Pipe:
    def __init__(self, pipe_x):
        self.pipe_hole_size = 125
        self.pipe_x = pipe_x
        self.speed = 3
        self.spawn = True
        self.scored = False

        self.pipe_height = random.randint(50, heigth - 100)

        self.pipe_image = pygame.image.load('pipe1.png')
        self.pipe_rectangle1 = self.pipe_image.get_rect(bottomright=(self.pipe_x, self.pipe_height))

        self.pipe_image2 = pygame.image.load('pipe2.png')
        self.pipe_rectangle2 = self.pipe_image2.get_rect(topright=(self.pipe_x, self.pipe_height + self.pipe_hole_size))

    def pipe_move(self):
        self.pipe_x -= self.speed
        self.pipe_rectangle1 = self.pipe_image.get_rect(bottomright=(self.pipe_x, self.pipe_height))
        self.pipe_rectangle2 = self.pipe_image2.get_rect(topright=(self.pipe_x, self.pipe_height + self.pipe_hole_size))

    def blit_draw(self):
        screen.blit(self.pipe_image, self.pipe_rectangle1)
        screen.blit(self.pipe_image2, self.pipe_rectangle2)

    def count(self, x):
        x1 = 0
        if x <= self.pipe_x:
            x1 += 1
            return x1

#  ____________________________________________________________________________________________________________________


class Background(pygame.sprite.Sprite):
    def __init__(self, image_file, location):
        pygame.sprite.Sprite.__init__(self)  # call Sprite initializer
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location

#  ____________________________________________________________________________________________________________________


def score(bird, pipes):
    global hiscore
    font = pygame.font.Font('Flappy-Bird.ttf', 64)
    text = font.render(str(hiscore), True, (255, 255, 255), (0, 0, 255))
    text_rect = text.get_rect(topleft=(width / 2, 20))
    text.set_colorkey((0, 0, 255))

    for p in pipes:
        if int(bird.width + bird.bird_rectangle1[2]) > p.pipe_rectangle1[0] + 100 and not p.scored:
            hiscore += 1
            p.scored = True
            text = font.render(str(hiscore), True, (255, 255, 255), (0, 0, 0))
            text_rect = text.get_rect(topleft=(width - 20, 20))
        screen.blit(text, text_rect)
# bird.width, p.upper_pipe_rect[0]

#  ____________________________________________________________________________________________________________________


class Records:
    def __init__(self):
        global hiscore
        self.hiscores_list = []
        self.file = open('hiscore.txt', 'r', encoding='utf8')
        for line in self.file:
            self.hiscores_list.append(line)
        self.file.close()

    def add_score(self):
        user_score = input('Введите имя: ') + ' '
        string = user_score + '//' + time.ctime() + '//' + str(hiscore)
        self.hiscores_list.append(string + '\n')

    def save_hiscore(self):
        self.file = open('hiscore.txt', 'w', encoding='utf8')
        for line in self.hiscores_list:
            self.file.write(line)
        self.file.close()

    def sort(self):
        a = []
        strng = ''
        for line in range(len(self.hiscores_list)):
            a.append([])
            for it in self.hiscores_list[line].split('//'):
                a[line].append(it)
            # a[line][2] = a[line][2].replace('\n', '')
        a.sort(key=lambda d: d[2], reverse=True)
        self.hiscores_list = []
        for line in a:
            if a.index(line) <= 9:
                for it in line:
                    if '\n' not in it:
                        strng += it + '//'
                    else:
                        strng += it
                self.hiscores_list.append(strng)
                strng = ''

    def show_records(self):
        self.file = open('hiscore.txt', 'r', encoding='utf8')
        file_list = self.file.readlines()
        y = 60

        for i in file_list:
            string = i.split('//')
            string = ''.join(string)
            font = pygame.font.Font('Flappy-Bird.ttf', 30)
            text = font.render(string, False, (255, 165, 0), (0, 0, 255))
            # text_rect = text.get_rect(topleft=(width / 2, 50))
            text.set_colorkey((0, 0, 255))

            # text = font.render(i, True, (255, 255, 255), (0, 0, 0))
            text_rect = text.get_rect(topleft=(width / 3, y))

            screen.blit(text, text_rect)
            y += 50

            # text = font.render(str(12345), True, (255, 255, 255), (0, 0, 0))
            # text_rect = text.get_rect(topleft=(width - 20, 20))
#  ____________________________________________________________________________________________________________________


def records_text():
    font = pygame.font.Font('Flappy-Bird.ttf', 64)
    text = font.render(('Records'), False, (255, 165, 0), (0, 0, 255))
    text_rect = text.get_rect(topleft=(width / 2 - 55, 5))
    text.set_colorkey((0, 0, 255))
    screen.blit(text, text_rect)
#  ____________________________________________________________________________________________________________________


def change_background():
    global trigger
    if trigger == False:
        trigger = True
        BackGround = Background('background_image.png', [0, 0])
    else:
        trigger = False
        BackGround = Background('night_city.png', [0, 0])
    return BackGround

#  ____________________________________________________________________________________________________________main_code


BackGround = change_background()

running = True

# menu = Menu()
# menu.main_menu()

pygame.mixer.music.load('music.mp3')
pygame.mixer.music.play(-1)

# pipe_width1 = width - 100
# pipe_width2 = width / 2 + 50

#  main_menu()
game = True

while game:
    bird = Bird()
    pipe = [Pipe(300 + i * 350) for i in range(1, 4)]
    records = Records()
    waiting_screen = True
    menu = True
    running = False
    bird.bird_spawn()

    while menu:
        screen.fill((255, 255, 255))
        pygame.draw.rect(screen, (255, 69, 0), (250, 50, 350, 500))
        records_text()
        records.show_records()
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                    waiting_screen = True
                    menu = False

    while waiting_screen:
        screen.fill([255, 255, 255])
        screen.blit(BackGround.image, BackGround.rect)
        bird.draw()
        pygame.display.flip()
        hiscore = 0

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                running = True
                waiting_screen = False

    while running:
        screen.fill([255, 255, 255])
        screen.blit(BackGround.image, BackGround.rect)
        bird.bird_spawn()
        bird.movement()
        bird.draw()

        for p in range(len(pipe)):
            pipe[p].pipe_move()

            if pipe[p].pipe_x >= 0:
                pipe[p].blit_draw()
            else:
                pipe[p] = Pipe(1000)

            if pipe[p].pipe_rectangle1.colliderect(bird.bird_rectangle1) or \
                    pipe[p].pipe_rectangle2.colliderect(bird.bird_rectangle1):
                running = False
                menu = True

        score(bird, pipe)

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                bird.jump()

        if bird.coords[1] >= heigth:
            running = False
            menu = True

        pygame.display.flip()
        clock.tick(30)

    records = Records()
    records.add_score()
    records.sort()
    records.save_hiscore()


        # pygame.display.update(size)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game = False


pygame.mixer.music.stop()

