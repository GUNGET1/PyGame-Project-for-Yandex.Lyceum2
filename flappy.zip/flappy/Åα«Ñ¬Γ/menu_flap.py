import pygame
import pygameMenu




def flappy_menu(surface, window_width, window_height, title):
    font1 = pygameMenu.font.FONT_OPEN_SANS
    menu = pygameMenu.Menu(surface, window_width, window_height, title=title, font=font1)
    menu.add_option('Старт', 'Close Menu', pygameMenu.events.CLOSE)
    return menu
